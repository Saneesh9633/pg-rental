"use client";
import { useState, useMemo } from "react";
import { createClient } from "@/lib/supabase-client";
import type { Tenant, Payment } from "@/types";
import { useRouter } from "next/navigation";

function fmt(n: number) { return "₹" + n.toLocaleString("en-IN"); }

function displayMonth(m: string) {
  const [y, mo] = m.split("-");
  return new Date(parseInt(y), parseInt(mo) - 1).toLocaleString("en-IN", { month: "long", year: "numeric" });
}

const EMPTY_FORM = { tenant_id: "", month: "", rent: 4000, food: 3500, extra: 0, note: "", status: "pending" as "paid" | "pending" };

export default function PaymentsClient({ tenants, payments: initial }: { tenants: Partial<Tenant>[]; payments: Payment[] }) {
  const router = useRouter();
  const [payments, setPayments] = useState(initial);
  const [filterTenant, setFilterTenant] = useState("all");
  const [filterMonth, setFilterMonth] = useState("all");
  const [filterStatus, setFilterStatus] = useState("all");
  const [modal, setModal] = useState(false);
  const [editing, setEditing] = useState<Payment | null>(null);
  const [form, setForm] = useState({ ...EMPTY_FORM });
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");

  const months = useMemo(() => [...new Set(payments.map(p => p.month))].sort().reverse(), [payments]);

  const filtered = useMemo(() => payments.filter(p =>
    (filterTenant === "all" || p.tenant_id === filterTenant) &&
    (filterMonth === "all" || p.month === filterMonth) &&
    (filterStatus === "all" || p.status === filterStatus)
  ), [payments, filterTenant, filterMonth, filterStatus]);

  function openAdd() {
    setEditing(null);
    setForm({ ...EMPTY_FORM, tenant_id: tenants[0]?.id ?? "" });
    setError("");
    setModal(true);
  }

  function openEdit(p: Payment) {
    setEditing(p);
    setForm({ tenant_id: p.tenant_id, month: p.month, rent: p.rent, food: p.food, extra: p.extra, note: p.note, status: p.status });
    setError("");
    setModal(true);
  }

  async function handleSave() {
    if (!form.tenant_id || !form.month) { setError("Please fill tenant and month."); return; }
    setSaving(true);
    setError("");
    const supabase = createClient();
    const payload = { ...form, paid_on: form.status === "paid" ? new Date().toISOString().slice(0, 10) : null };

    if (editing) {
      const { error } = await supabase.from("payments").update(payload).eq("id", editing.id);
      if (error) { setError(error.message); setSaving(false); return; }
    } else {
      const { error } = await supabase.from("payments").insert(payload);
      if (error) { setError(error.message); setSaving(false); return; }
    }
    setSaving(false);
    setModal(false);
    router.refresh();
  }

  async function handleDelete(id: string) {
    if (!confirm("Delete this payment record?")) return;
    const supabase = createClient();
    await supabase.from("payments").delete().eq("id", id);
    setPayments(prev => prev.filter(p => p.id !== id));
  }

  async function toggleStatus(p: Payment) {
    const newStatus = p.status === "paid" ? "pending" : "paid";
    const supabase = createClient();
    await supabase.from("payments").update({ status: newStatus, paid_on: newStatus === "paid" ? new Date().toISOString().slice(0, 10) : null }).eq("id", p.id);
    setPayments(prev => prev.map(r => r.id === p.id ? { ...r, status: newStatus } : r));
  }

  return (
    <div className="max-w-5xl space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-semibold text-gray-900">Payments</h1>
          <p className="text-sm text-gray-500 mt-0.5">{filtered.length} records</p>
        </div>
        <button onClick={openAdd} className="btn-primary flex items-center gap-2">
          <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" /></svg>
          Add payment
        </button>
      </div>

      <div className="flex gap-3 flex-wrap">
        <select value={filterTenant} onChange={e => setFilterTenant(e.target.value)} className="text-sm border border-gray-200 rounded-lg px-3 py-2 bg-white focus:outline-none focus:ring-2 focus:ring-indigo-400">
          <option value="all">All tenants</option>
          {tenants.map(t => <option key={t.id} value={t.id}>{t.name}</option>)}
        </select>
        <select value={filterMonth} onChange={e => setFilterMonth(e.target.value)} className="text-sm border border-gray-200 rounded-lg px-3 py-2 bg-white focus:outline-none focus:ring-2 focus:ring-indigo-400">
          <option value="all">All months</option>
          {months.map(m => <option key={m} value={m}>{displayMonth(m)}</option>)}
        </select>
        <select value={filterStatus} onChange={e => setFilterStatus(e.target.value)} className="text-sm border border-gray-200 rounded-lg px-3 py-2 bg-white focus:outline-none focus:ring-2 focus:ring-indigo-400">
          <option value="all">All statuses</option>
          <option value="paid">Paid</option>
          <option value="pending">Pending</option>
        </select>
      </div>

      <div className="card overflow-hidden">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-gray-100 bg-gray-50">
              <th className="text-left px-4 py-3 text-xs font-medium text-gray-500">Tenant</th>
              <th className="text-left px-4 py-3 text-xs font-medium text-gray-500">Month</th>
              <th className="text-right px-4 py-3 text-xs font-medium text-gray-500">Rent</th>
              <th className="text-right px-4 py-3 text-xs font-medium text-gray-500">Food</th>
              <th className="text-right px-4 py-3 text-xs font-medium text-gray-500">Extra</th>
              <th className="text-right px-4 py-3 text-xs font-medium text-gray-500">Total</th>
              <th className="text-center px-4 py-3 text-xs font-medium text-gray-500">Status</th>
              <th className="px-4 py-3 text-xs font-medium text-gray-500"></th>
            </tr>
          </thead>
          <tbody>
            {filtered.length === 0 && (
              <tr><td colSpan={8} className="text-center py-10 text-gray-400">No records found</td></tr>
            )}
            {filtered.map(p => {
              const total = p.rent + p.food + p.extra;
              return (
                <tr key={p.id} className="border-b border-gray-50 hover:bg-gray-50 transition-colors">
                  <td className="px-4 py-3 font-medium text-gray-800">
                    {(p as any).tenant?.name ?? "—"}
                    <span className="text-xs text-gray-400 ml-1">{(p as any).tenant?.room_no}</span>
                  </td>
                  <td className="px-4 py-3 text-gray-500">{displayMonth(p.month)}</td>
                  <td className="px-4 py-3 text-right text-gray-700">{fmt(p.rent)}</td>
                  <td className="px-4 py-3 text-right text-gray-700">{p.food ? fmt(p.food) : "—"}</td>
                  <td className="px-4 py-3 text-right text-gray-700">{p.extra ? fmt(p.extra) : "—"}</td>
                  <td className="px-4 py-3 text-right font-medium text-gray-900">{fmt(total)}</td>
                  <td className="px-4 py-3 text-center">
                    <button onClick={() => toggleStatus(p)} className={p.status === "paid" ? "badge-paid cursor-pointer" : "badge-pending cursor-pointer"}>
                      {p.status === "paid" ? "Paid" : "Pending"}
                    </button>
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex gap-2 justify-end">
                      <button onClick={() => openEdit(p)} className="text-gray-400 hover:text-indigo-600 transition-colors">
                        <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" /></svg>
                      </button>
                      <button onClick={() => handleDelete(p.id)} className="text-gray-400 hover:text-red-500 transition-colors">
                        <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg>
                      </button>
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {modal && (
        <div className="fixed inset-0 bg-black/30 flex items-center justify-center z-50">
          <div className="bg-white rounded-xl shadow-lg w-full max-w-md mx-4 p-6">
            <h2 className="text-base font-semibold text-gray-900 mb-5">{editing ? "Edit payment" : "Add payment"}</h2>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Tenant</label>
                <select className="input" value={form.tenant_id} onChange={e => setForm(f => ({ ...f, tenant_id: e.target.value }))}>
                  <option value="">Select tenant</option>
                  {tenants.map(t => <option key={t.id} value={t.id}>{t.name} — {t.room_no}</option>)}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Month (YYYY-MM)</label>
                <input type="month" className="input" value={form.month} onChange={e => setForm(f => ({ ...f, month: e.target.value }))} />
              </div>
              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Rent (₹)</label>
                  <input type="number" className="input" value={form.rent} onChange={e => setForm(f => ({ ...f, rent: Number(e.target.value) }))} />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Food (₹)</label>
                  <input type="number" className="input" value={form.food} onChange={e => setForm(f => ({ ...f, food: Number(e.target.value) }))} />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Extra (₹)</label>
                  <input type="number" className="input" value={form.extra} onChange={e => setForm(f => ({ ...f, extra: Number(e.target.value) }))} />
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Note (optional)</label>
                <input type="text" className="input" placeholder="e.g. Late fee included" value={form.note} onChange={e => setForm(f => ({ ...f, note: e.target.value }))} />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Status</label>
                <select className="input" value={form.status} onChange={e => setForm(f => ({ ...f, status: e.target.value as "paid" | "pending" }))}>
                  <option value="pending">Pending</option>
                  <option value="paid">Paid</option>
                </select>
              </div>
              {error && <p className="text-sm text-red-600 bg-red-50 px-3 py-2 rounded-lg">{error}</p>}
            </div>
            <div className="flex gap-3 mt-6">
              <button onClick={() => setModal(false)} className="btn-secondary flex-1">Cancel</button>
              <button onClick={handleSave} disabled={saving} className="btn-primary flex-1">{saving ? "Saving…" : "Save"}</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

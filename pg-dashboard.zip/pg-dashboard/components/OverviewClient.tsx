"use client";
import { useMemo, useState } from "react";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell } from "recharts";
import type { Tenant, Payment } from "@/types";

function fmt(n: number) {
  return "₹" + n.toLocaleString("en-IN");
}

function StatCard({ label, value, sub, color = "text-gray-900" }: { label: string; value: string; sub?: string; color?: string }) {
  return (
    <div className="card p-5">
      <p className="text-xs text-gray-500 font-medium uppercase tracking-wide mb-2">{label}</p>
      <p className={`text-2xl font-semibold ${color}`}>{value}</p>
      {sub && <p className="text-xs text-gray-400 mt-1">{sub}</p>}
    </div>
  );
}

export default function OverviewClient({ tenants, payments }: { tenants: Tenant[]; payments: Payment[] }) {
  const [selectedMonth, setSelectedMonth] = useState("all");

  const months = useMemo(() => {
    const set = new Set(payments.map(p => p.month));
    return Array.from(set).sort().reverse();
  }, [payments]);

  const filtered = useMemo(() =>
    selectedMonth === "all" ? payments : payments.filter(p => p.month === selectedMonth),
    [payments, selectedMonth]
  );

  const totalBilled = filtered.reduce((s, p) => s + p.rent + p.food + p.extra, 0);
  const totalCollected = filtered.filter(p => p.status === "paid").reduce((s, p) => s + p.rent + p.food + p.extra, 0);
  const totalPending = totalBilled - totalCollected;
  const pendingCount = filtered.filter(p => p.status === "pending").length;

  const byTenant = useMemo(() => {
    return tenants.map(t => {
      const rows = filtered.filter(p => p.tenant_id === t.id);
      const collected = rows.filter(p => p.status === "paid").reduce((s, p) => s + p.rent + p.food + p.extra, 0);
      const pending = rows.filter(p => p.status === "pending").reduce((s, p) => s + p.rent + p.food + p.extra, 0);
      return { name: t.name, room: t.room_no, collected, pending };
    });
  }, [tenants, filtered]);

  const monthlyChart = useMemo(() => {
    return months.slice(0, 6).reverse().map(m => {
      const rows = payments.filter(p => p.month === m);
      const collected = rows.filter(p => p.status === "paid").reduce((s, p) => s + p.rent + p.food + p.extra, 0);
      const pending = rows.filter(p => p.status === "pending").reduce((s, p) => s + p.rent + p.food + p.extra, 0);
      const [y, mo] = m.split("-");
      const label = new Date(parseInt(y), parseInt(mo) - 1).toLocaleString("en-IN", { month: "short", year: "2-digit" });
      return { label, collected, pending };
    });
  }, [months, payments]);

  function displayMonth(m: string) {
    const [y, mo] = m.split("-");
    return new Date(parseInt(y), parseInt(mo) - 1).toLocaleString("en-IN", { month: "long", year: "numeric" });
  }

  return (
    <div className="space-y-6 max-w-5xl">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-semibold text-gray-900">Overview</h1>
          <p className="text-sm text-gray-500 mt-0.5">Track rent and food collection</p>
        </div>
        <select
          value={selectedMonth}
          onChange={e => setSelectedMonth(e.target.value)}
          className="text-sm border border-gray-200 rounded-lg px-3 py-2 bg-white text-gray-700 focus:outline-none focus:ring-2 focus:ring-indigo-400">
          <option value="all">All months</option>
          {months.map(m => <option key={m} value={m}>{displayMonth(m)}</option>)}
        </select>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <StatCard label="Active tenants" value={String(tenants.length)} sub="Currently staying" />
        <StatCard label="Total billed" value={fmt(totalBilled)} sub="Rent + food + extras" />
        <StatCard label="Collected" value={fmt(totalCollected)} color="text-green-700" sub="Paid entries" />
        <StatCard label="Pending" value={fmt(totalPending)} color="text-red-600" sub={`${pendingCount} unpaid`} />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="card p-5">
          <h2 className="text-sm font-medium text-gray-700 mb-4">Collection by tenant</h2>
          <div className="space-y-3">
            {byTenant.map(t => {
              const total = t.collected + t.pending;
              const pct = total > 0 ? Math.round((t.collected / total) * 100) : 0;
              return (
                <div key={t.name}>
                  <div className="flex justify-between text-sm mb-1">
                    <span className="text-gray-700 font-medium">{t.name} <span className="text-gray-400 font-normal text-xs">· {t.room}</span></span>
                    <span className="text-gray-500">{fmt(t.collected)} / {fmt(total)}</span>
                  </div>
                  <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
                    <div className="h-2 bg-indigo-500 rounded-full transition-all" style={{ width: `${pct}%` }} />
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        <div className="card p-5">
          <h2 className="text-sm font-medium text-gray-700 mb-4">Monthly trend</h2>
          <ResponsiveContainer width="100%" height={180}>
            <BarChart data={monthlyChart} barSize={16} barGap={4}>
              <XAxis dataKey="label" tick={{ fontSize: 11, fill: "#9ca3af" }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 11, fill: "#9ca3af" }} axisLine={false} tickLine={false} tickFormatter={v => "₹" + (v / 1000) + "k"} />
              <Tooltip formatter={(v: number) => fmt(v)} contentStyle={{ fontSize: 12, borderRadius: 8, border: "1px solid #e5e7eb" }} />
              <Bar dataKey="collected" name="Collected" fill="#6366f1" radius={[3, 3, 0, 0]} />
              <Bar dataKey="pending" name="Pending" fill="#fee2e2" radius={[3, 3, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
          <div className="flex gap-4 mt-2 justify-center">
            <span className="flex items-center gap-1 text-xs text-gray-500"><span className="w-2.5 h-2.5 rounded-sm bg-indigo-500 inline-block"></span>Collected</span>
            <span className="flex items-center gap-1 text-xs text-gray-500"><span className="w-2.5 h-2.5 rounded-sm bg-red-100 inline-block"></span>Pending</span>
          </div>
        </div>
      </div>
    </div>
  );
}

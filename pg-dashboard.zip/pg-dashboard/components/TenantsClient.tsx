"use client";
import { useState } from "react";
import { createClient } from "@/lib/supabase-client";
import type { Tenant } from "@/types";

const EMPTY: Partial<Tenant> = { name: "", room_no: "", phone: "", deposit: 0, join_date: new Date().toISOString().slice(0, 10), active: true };

export default function TenantsClient({ tenants: initial }: { tenants: Tenant[] }) {
  const [tenants, setTenants] = useState(initial);
  const [modal, setModal] = useState(false);
  const [editing, setEditing] = useState<Tenant | null>(null);
  const [form, setForm] = useState<Partial<Tenant>>({ ...EMPTY });
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");

  function openAdd() { setEditing(null); setForm({ ...EMPTY }); setError(""); setModal(true); }
  function openEdit(t: Tenant) { setEditing(t); setForm({ ...t }); setError(""); setModal(true); }

  async function handleSave() {
    if (!form.name || !form.room_no) { setError("Name and room number are required."); return; }
    setSaving(true); setError("");
    const supabase = createClient();
    if (editing) {
      const { error } = await supabase.from("tenants").update(form).eq("id", editing.id);
      if (error) { setError(error.message); setSaving(false); return; }
      setTenants(prev => prev.map(t => t.id === editing.id ? { ...t, ...form } as Tenant : t));
    } else {
      const { data, error } = await supabase.from("tenants").insert(form).select().single();
      if (error) { setError(error.message); setSaving(false); return; }
      setTenants(prev => [...prev, data]);
    }
    setSaving(false); setModal(false);
  }

  async function toggleActive(t: Tenant) {
    const supabase = createClient();
    await supabase.from("tenants").update({ active: !t.active }).eq("id", t.id);
    setTenants(prev => prev.map(r => r.id === t.id ? { ...r, active: !r.active } : r));
  }

  const active = tenants.filter(t => t.active);
  const inactive = tenants.filter(t => !t.active);

  return (
    <div className="max-w-4xl space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-semibold text-gray-900">Tenants</h1>
          <p className="text-sm text-gray-500 mt-0.5">{active.length} active · {inactive.length} past</p>
        </div>
        <button onClick={openAdd} className="btn-primary flex items-center gap-2">
          <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" /></svg>
          Add tenant
        </button>
      </div>

      <div className="card overflow-hidden">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-gray-100 bg-gray-50">
              <th className="text-left px-4 py-3 text-xs font-medium text-gray-500">Name</th>
              <th className="text-left px-4 py-3 text-xs font-medium text-gray-500">Room</th>
              <th className="text-left px-4 py-3 text-xs font-medium text-gray-500">Phone</th>
              <th className="text-right px-4 py-3 text-xs font-medium text-gray-500">Deposit</th>
              <th className="text-left px-4 py-3 text-xs font-medium text-gray-500">Joined</th>
              <th className="text-center px-4 py-3 text-xs font-medium text-gray-500">Status</th>
              <th className="px-4 py-3"></th>
            </tr>
          </thead>
          <tbody>
            {tenants.map(t => (
              <tr key={t.id} className="border-b border-gray-50 hover:bg-gray-50 transition-colors">
                <td className="px-4 py-3 font-medium text-gray-800">
                  <div className="flex items-center gap-2">
                    <div className="w-7 h-7 rounded-full bg-indigo-50 flex items-center justify-center text-xs font-medium text-indigo-700">
                      {t.name.slice(0, 2).toUpperCase()}
                    </div>
                    {t.name}
                  </div>
                </td>
                <td className="px-4 py-3 text-gray-600">{t.room_no}</td>
                <td className="px-4 py-3 text-gray-500">{t.phone || "—"}</td>
                <td className="px-4 py-3 text-right text-gray-700">₹{t.deposit.toLocaleString("en-IN")}</td>
                <td className="px-4 py-3 text-gray-500">{new Date(t.join_date).toLocaleDateString("en-IN")}</td>
                <td className="px-4 py-3 text-center">
                  <span className={t.active ? "badge-paid" : "inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-gray-100 text-gray-500"}>
                    {t.active ? "Active" : "Inactive"}
                  </span>
                </td>
                <td className="px-4 py-3">
                  <div className="flex gap-2 justify-end">
                    <button onClick={() => openEdit(t)} className="text-gray-400 hover:text-indigo-600 transition-colors">
                      <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" /></svg>
                    </button>
                    <button onClick={() => toggleActive(t)} className="text-gray-400 hover:text-amber-500 transition-colors" title={t.active ? "Mark inactive" : "Mark active"}>
                      <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M18.364 18.364A9 9 0 005.636 5.636m12.728 12.728A9 9 0 015.636 5.636m12.728 12.728L5.636 5.636" /></svg>
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {modal && (
        <div className="fixed inset-0 bg-black/30 flex items-center justify-center z-50">
          <div className="bg-white rounded-xl shadow-lg w-full max-w-md mx-4 p-6">
            <h2 className="text-base font-semibold text-gray-900 mb-5">{editing ? "Edit tenant" : "Add tenant"}</h2>
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Full name</label>
                  <input type="text" className="input" placeholder="Arif" value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Room no.</label>
                  <input type="text" className="input" placeholder="Room 1" value={form.room_no} onChange={e => setForm(f => ({ ...f, room_no: e.target.value }))} />
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Phone</label>
                <input type="text" className="input" placeholder="9876500000" value={form.phone ?? ""} onChange={e => setForm(f => ({ ...f, phone: e.target.value }))} />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Deposit (₹)</label>
                  <input type="number" className="input" value={form.deposit} onChange={e => setForm(f => ({ ...f, deposit: Number(e.target.value) }))} />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Join date</label>
                  <input type="date" className="input" value={form.join_date} onChange={e => setForm(f => ({ ...f, join_date: e.target.value }))} />
                </div>
              </div>
              {error && <p className="text-sm text-red-600 bg-red-50 px-3 py-2 rounded-lg">{error}</p>}
            </div>
            <div className="flex gap-3 mt-6">
              <button onClick={() => setModal(false)} className="btn-secondary flex-1">Cancel</button>
              <button onClick={handleSave} disabled={saving} className="btn-primary flex-1">{saving ? "Saving…" : "Save tenant"}</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

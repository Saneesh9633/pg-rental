import { createServerSupabaseClient } from "@/lib/supabase-server";
import TenantsClient from "@/components/TenantsClient";

export default async function TenantsPage() {
  const supabase = createServerSupabaseClient();
  const { data: tenants } = await supabase.from("tenants").select("*").order("name");
  return <TenantsClient tenants={tenants ?? []} />;
}

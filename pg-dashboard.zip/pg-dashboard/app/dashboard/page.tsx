import { createServerSupabaseClient } from "@/lib/supabase-server";
import OverviewClient from "@/components/OverviewClient";

export default async function DashboardPage() {
  const supabase = createServerSupabaseClient();

  const [{ data: tenants }, { data: payments }] = await Promise.all([
    supabase.from("tenants").select("*").eq("active", true).order("name"),
    supabase.from("payments").select("*, tenant:tenants(name, room_no)").order("month", { ascending: false }),
  ]);

  return <OverviewClient tenants={tenants ?? []} payments={payments ?? []} />;
}

import { createServerSupabaseClient } from "@/lib/supabase-server";
import PaymentsClient from "@/components/PaymentsClient";

export default async function PaymentsPage() {
  const supabase = createServerSupabaseClient();
  const [{ data: tenants }, { data: payments }] = await Promise.all([
    supabase.from("tenants").select("id, name, room_no").eq("active", true).order("name"),
    supabase.from("payments").select("*, tenant:tenants(name, room_no)").order("month", { ascending: false }),
  ]);

  return <PaymentsClient tenants={tenants ?? []} payments={payments ?? []} />;
}

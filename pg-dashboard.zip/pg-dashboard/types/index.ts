export type Tenant = {
  id: string;
  name: string;
  room_no: string;
  phone: string;
  deposit: number;
  join_date: string;
  active: boolean;
  created_at: string;
};

export type Payment = {
  id: string;
  tenant_id: string;
  month: string;        // "2026-06"
  rent: number;
  food: number;
  extra: number;        // any extra charge
  note: string;
  status: "paid" | "pending";
  paid_on: string | null;
  created_at: string;
  tenant?: Tenant;
};

export type MonthlySummary = {
  month: string;
  total_billed: number;
  total_collected: number;
  pending_count: number;
};
